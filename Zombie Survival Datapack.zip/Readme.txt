Just move "Zombie Survival Datapack.zip" to the datapack folder of your world

Use this datapack for whatever you want just make sure to credit me